﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;


namespace BusinessLayer
{
    public class Device
    {
        public int ID { get; set; }
        public string IMEI { get; set; }
        public string Model { get; set; }
        public string SimCardNumber { get; set; }
        public bool Enable { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string Createdby { get; set; }
        public int BackendID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }

    }
}
