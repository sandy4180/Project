﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
   public class DeviceBusinessLayer
    {
        public IEnumerable<Device> Devices
        {
            get
            {
                string connectionString =
                    ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

                List<Device> devices = new List<Device>();

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("USP_GetDeviceData", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Device  device = new Device();
                        device.ID = Convert.ToInt32(rdr["ID"]);
                        device.IMEI= rdr["IMEI"].ToString();
                        device.Model= rdr["Model"].ToString();
                        device.SimCardNumber  = rdr["SimCardNumber"].ToString();
                        device.Enable =Convert.ToBoolean(rdr["Enable"]);
                        device.CreatedDateTime= Convert.ToDateTime(rdr["CreatedDateTime"]);
                        device .Createdby = rdr["Createdby"].ToString();
                        device.Name = rdr["Name"].ToString();
                        device.Address= rdr["Address"].ToString();
                        device.BackendID = Convert.ToInt32(rdr["BackendID"]);
                        devices.Add(device);
                    }
                }

                return devices;
            }
        }

        public void AddDevice(Device  device)
        {
            string connectionString =
                    ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_InsertDevice", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IMEI", device.IMEI);
                cmd.Parameters.AddWithValue("@Model", device.Model);
                cmd.Parameters.AddWithValue("@SimCardNumber", device.SimCardNumber);
                cmd.Parameters.AddWithValue("@Enable", device.Enable);
                cmd.Parameters.AddWithValue("@CreatedDateTime", device.CreatedDateTime);
                cmd.Parameters.AddWithValue("@Createdby", device.Createdby);
                cmd.Parameters.AddWithValue("@NAME", device.Name);
                cmd.Parameters.AddWithValue("@Address", device.Address);  

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateDevice(Device device)
        {
            string connectionString =
                    ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_UpdateDevice", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IMEI", device.IMEI);
                cmd.Parameters.AddWithValue("@Model", device.Model);
                cmd.Parameters.AddWithValue("@SimCardNumber", device.SimCardNumber);
                cmd.Parameters.AddWithValue("@Enable", device.Enable);
                cmd.Parameters.AddWithValue("@CreatedDateTime", device.CreatedDateTime);
                cmd.Parameters.AddWithValue("@Createdby", device.Createdby);
                cmd.Parameters.AddWithValue("@NAME", device.Name);
                cmd.Parameters.AddWithValue("@Address", device.Address);
                cmd.Parameters.AddWithValue("@ID", device.ID);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void DeleteDevice(int id)
        {
            string connectionString =
                    ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_DeleteDeviceData", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID",id);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
