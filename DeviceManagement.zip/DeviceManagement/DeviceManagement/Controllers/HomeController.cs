﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;

namespace DeviceManagement.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();
            List<Device> devices = deviceBusinessLayer.Devices.ToList();
            return View(devices);           
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(FormCollection formCollection)
        {
            if (ModelState.IsValid)
            {
                DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();
                Device device = new Device();
                UpdateModel<Device>(device);
                deviceBusinessLayer.AddDevice(device);
                     return RedirectToAction("Index");
            }
            return View();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();
            Device device =
                   deviceBusinessLayer.Devices.Single(dev => dev.ID == id);

            return View(device);
        }
        [HttpPost]
        public ActionResult Edit(Device device)
        {
            if (ModelState.IsValid)
            {
                DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();

                deviceBusinessLayer.UpdateDevice (device);

                return RedirectToAction("Index");
            }
            return View(device);
        }
     
        public ActionResult Delete(int id)
        {
            DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();
            deviceBusinessLayer.DeleteDevice(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Details(int id)
        {
            DeviceBusinessLayer deviceBusinessLayer = new DeviceBusinessLayer();
            Device device =
                   deviceBusinessLayer.Devices.Single(dev => dev.ID == id);

            return View(device);
        }
    }
}